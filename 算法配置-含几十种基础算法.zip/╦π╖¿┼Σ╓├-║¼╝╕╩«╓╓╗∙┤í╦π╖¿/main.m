clc
clear all
close all
addpath("对比算法")
addpath("算法测试集")

%% 参数初始化定义
% 算法列表
% SSA,AROA,DTBO,
% 'AOA','CSA','DTBO','BKA','AVOA','CBOA','INFO','MPA','NGO','OIO','POA','SABO','SCSO','SHO','SO','STOA',
% 'WSO','YSGA','ZOA','MVO','PSO','MFO','GWO','WOA','HHO','AO','CPSOGSA','RIME']
%若想替换其他算法，直接CTRL+H，将algorithms中的算法替换即可
algorithms = {'PSO','GWO'};
nPop = 100;                  %种群数
Max_iter = 1000;             %最大迭代次数
dim = 50;                   %可选 10、30、50、100

for j = 1:1
    %% 选择函数

    Function_name = j; % 函数名： 1 - 30
    [lb, ub, dim, fobj] = Get_Functions_cec2017(Function_name, dim);

    %% GWO算法（灰狼算法）
    tic
    [GWO_Best_score, GWO_Best_pos, GWO_cg_curve] = GWO(nPop, Max_iter, lb, ub, dim, fobj);
    toc
    display(['The best optimal value of the objective function found by GWO for F' num2str(Function_name), ' is: ', num2str(GWO_Best_score)]);
    fprintf('Best solution obtained by GWO: %s\n', num2str(GWO_Best_pos, '%e  '));
    

    %% PSO算法（粒子群算法）
    tic
    [PSO_Best_score, PSO_Best_pos, PSO_cg_curve] = PSO(nPop, Max_iter, lb, ub, dim, fobj);
    toc
    display(['The best optimal value of the objective function found by PSO for F' num2str(Function_name), ' is: ', num2str(PSO_Best_score)]);
    fprintf('Best solution obtained by PSO: %s\n', num2str(PSO_Best_pos, '%e  '));
    

    %% plot绘图
    figure;
    colors = lines(length(algorithms));
    for i = 1:length(algorithms)
        semilogy(eval([algorithms{i} '_cg_curve']), 'Color', colors(i, :), 'LineWidth', 1);
        hold on
    end
    title(['Convergence curve, dim=' num2str(dim)])
    xlabel('Iteration')
    ylabel(['Best score F' num2str(Function_name)])
    axis tight
    grid on
    box on
    set(gca, 'color', 'none')
    % Add legend
    legend(algorithms, 'Location', 'Best');
end