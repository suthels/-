function [Best_fitness,Xbest,  Iter_curve] = HOA(pop, maxIter, lb, ub, dim, fobj)
    %% Pre-allocate
    fit = zeros(pop, 1); % Vectorize variable to store fitness value

    %% Start Tobler Hiking Function Optimizer
    Pop = repmat(lb, pop, 1) + repmat((ub - lb), pop, 1) .* rand(pop, dim); % Generate initial position of hiker

    %% Evaluate fitness
    for q = 1:pop
        fit(q) = fobj(Pop(q, :)); % Evaluating initial fitness
    end

    %% Main Loop
    for i = 1:maxIter
        [~, ind] = min(fit); % Obtain initial fitness
        Xbest = Pop(ind, :); % Obtain global best position of initial fitness
        Best_fitness = min(fit);

        for j = 1:pop
            Xini = Pop(j, :); % Obtain initial position of jth hiker
            theta = randi([0 50], 1, 1); % Randomize elevation angle of hiker
            s = tan(theta); % Compute slope
            SF = randi([1 2], 1, 1); % Sweep factor generate either 1 or 2 randomly
            Vel = 6. * exp(-3.5 .* abs(s + 0.05)); % Compute walking velocity based on Tobler's Hiking Function
            newVel = Vel + rand(1, dim) .* (Xbest - SF .* Xini); % Determine new position of hiker
            newPop = Pop(j, :) + newVel; % Update position of hiker
            newPop = min(ub, newPop); % Bound violating to upper bound
            newPop = max(lb, newPop); % Bound violating to lower bound
            fnew = fobj(newPop); % Re-evaluate fitness

            if (fnew < fit(j)) % Apply greedy selection strategy
                Pop(j, :) = newPop; % Store best position
                fit(j) = fnew; % Store new fitness
            end
        end

        Iter_curve(i) = min(fit); % Store best fitness per iteration
    end
end